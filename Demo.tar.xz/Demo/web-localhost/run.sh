#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

PORT="${PORT:-8787}"

if [[ ! -f "$ROOT_DIR/server/bridge-out/com/st8504/bridge/BridgeMain.class" ]]; then
  echo "Java bridge is not built yet. Running ./build-bridge.sh ..."
  "$ROOT_DIR/build-bridge.sh"
fi

exec node "$ROOT_DIR/server/server.js" --port "$PORT"

