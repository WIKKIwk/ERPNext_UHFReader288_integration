package com.st8504.bridge;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public final class BridgeMain {
  private final Object outLock = new Object();

  private Object reader; // com.rfid.CReader
  private Object tagCallbackProxy; // com.rfid.TagCallback
  private boolean inventoryStarted = false;

  private Map<String, Object> lastConnectArgs = null;

  public static void main(String[] args) throws Exception {
    new BridgeMain().run();
  }

  private void run() throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
    String line;
    while ((line = br.readLine()) != null) {
      line = line.trim();
      if (line.isEmpty()) continue;
      handleLine(line);
    }
  }

  private void handleLine(String line) {
    String[] parts = line.split("\t", -1);
    if (parts.length < 3 || !"REQ".equals(parts[0])) {
      sendEvent("LOG", jsonObj("level", "warn", "message", "Bad line: " + line));
      return;
    }
    int id = safeParseInt(parts[1], -1);
    String cmd = parts[2];
    String jsonArgs = parts.length >= 4 ? parts[3] : "{}";

    try {
      Map<String, Object> args = parseFlatJsonObject(jsonArgs);
      Object result = dispatch(cmd, args);
      sendResOk(id, result == null ? "{}" : toJson(result));
    } catch (Exception e) {
      sendResErr(id, e.getMessage() != null ? e.getMessage() : e.toString());
    }
  }

  private Object dispatch(String cmd, Map<String, Object> args) throws Exception {
    if ("STATUS".equals(cmd)) {
      Map<String, Object> st = new HashMap<String, Object>();
      st.put("connected", Boolean.valueOf(reader != null));
      st.put("inventoryStarted", Boolean.valueOf(inventoryStarted));
      st.put("lastConnectArgs", lastConnectArgs == null ? null : lastConnectArgs);
      return st;
    }

    if ("CONNECT".equals(cmd)) {
      String ip = str(args.get("ip"), "192.168.0.250");
      int port = intv(args.get("port"), 27011);
      int readerType = intv(args.get("readerType"), 16);
      int logSwitch = intv(args.get("logSwitch"), 0);

      disconnectInternal();
      Object r = newCReader(ip, port, readerType, logSwitch);
      int rc = intRet(invokeAny(r, "Connect"));
      if (rc != 0) throw new Exception("Connect failed: " + rc);
      this.reader = r;
      ensureCallback();
      this.lastConnectArgs = new HashMap<String, Object>();
      lastConnectArgs.put("ip", ip);
      lastConnectArgs.put("port", Integer.valueOf(port));
      lastConnectArgs.put("readerType", Integer.valueOf(readerType));
      lastConnectArgs.put("logSwitch", Integer.valueOf(logSwitch));
      sendEvent("STATUS", jsonObj("connected", Boolean.TRUE));
      return jsonObj("rc", Integer.valueOf(rc));
    }

    if ("DISCONNECT".equals(cmd)) {
      disconnectInternal();
      sendEvent("STATUS", jsonObj("connected", Boolean.FALSE));
      return jsonObj("ok", Boolean.TRUE);
    }

    requireConnected();

    if ("SET_INV_PARAM".equals(cmd)) {
      int qValue = intv(args.get("qValue"), 6);
      int session = intv(args.get("session"), 255);
      int scanTime = intv(args.get("scanTime"), 20);
      int antennaMask = intv(args.get("antennaMask"), 1);
      int tidPtr = intv(args.get("tidPtr"), 0);
      int tidLen = intv(args.get("tidLen"), 0);

      Object rp = newReaderParameter();
      safeInvoke(rp, "SetQValue", Integer.valueOf(qValue));
      safeInvoke(rp, "SetSession", Integer.valueOf(session));
      safeInvoke(rp, "SetScanTime", Integer.valueOf(scanTime));
      safeInvoke(rp, "SetAntenna", Integer.valueOf(antennaMask));
      safeInvoke(rp, "SetTidPtr", Integer.valueOf(tidPtr));
      safeInvoke(rp, "SetTidLen", Integer.valueOf(tidLen));

      invokeAny(reader, "SetInventoryParameter", rp);
      return jsonObj("ok", Boolean.TRUE);
    }

    if ("START_READ".equals(cmd)) {
      ensureCallback();
      int rc = intRet(invokeAny(reader, "StartRead"));
      // Some firmwares might return 0 for success; keep permissive.
      inventoryStarted = true;
      sendEvent("STATUS", jsonObj("inventoryStarted", Boolean.TRUE, "rc", Integer.valueOf(rc)));
      return jsonObj("rc", Integer.valueOf(rc));
    }

    if ("STOP_READ".equals(cmd)) {
      safeInvoke(reader, "StopRead");
      inventoryStarted = false;
      sendEvent("STATUS", jsonObj("inventoryStarted", Boolean.FALSE));
      return jsonObj("ok", Boolean.TRUE);
    }

    if ("READ".equals(cmd)) {
      String epc = str(args.get("epc"), "");
      int mem = intv(args.get("mem"), 3);
      int wordPtr = intv(args.get("wordPtr"), 0);
      int num = intv(args.get("num"), 2);
      String password = str(args.get("password"), "00000000");

      Object out = invokeAny(reader, "ReadDataByEPC", epc, Byte.valueOf((byte) mem), Byte.valueOf((byte) wordPtr), Byte.valueOf((byte) num), password);
      if (out == null) return jsonObj("data", null);
      return jsonObj("data", String.valueOf(out));
    }

    if ("WRITE".equals(cmd)) {
      String epc = str(args.get("epc"), "");
      int mem = intv(args.get("mem"), 3);
      int wordPtr = intv(args.get("wordPtr"), 0);
      String password = str(args.get("password"), "00000000");
      String data = str(args.get("data"), "");

      int rc = intRet(invokeAny(reader, "WriteDataByEPC", epc, Byte.valueOf((byte) mem), Byte.valueOf((byte) wordPtr), password, data));
      return jsonObj("rc", Integer.valueOf(rc));
    }

    if ("SET_POWER".equals(cmd)) {
      int power = intv(args.get("power"), 30);
      int rc = intRet(invokeAny(reader, "SetRfPower", Integer.valueOf(power)));
      return jsonObj("rc", Integer.valueOf(rc));
    }

    if ("SET_REGION".equals(cmd)) {
      int band = intv(args.get("band"), 0);
      int maxfre = intv(args.get("maxfre"), 0);
      int minfre = intv(args.get("minfre"), 0);
      int rc = intRet(invokeAny(reader, "SetRegion", Integer.valueOf(band), Integer.valueOf(maxfre), Integer.valueOf(minfre)));
      return jsonObj("rc", Integer.valueOf(rc));
    }

    if ("GPIO".equals(cmd)) {
      String op = str(args.get("op"), "get");
      if ("set".equalsIgnoreCase(op)) {
        int value = intv(args.get("value"), 0);
        int rc = intRet(invokeAny(reader, "SetGPIO", Byte.valueOf((byte) value)));
        return jsonObj("rc", Integer.valueOf(rc));
      }
      byte[] outPins = new byte[8];
      int rc = intRet(invokeAny(reader, "GetGPIOStatus", outPins));
      Map<String, Object> resp = new HashMap<String, Object>();
      resp.put("rc", Integer.valueOf(rc));
      resp.put("raw", bytesToHex(outPins));
      return resp;
    }

    if ("GET_INFO".equals(cmd)) {
      byte[] version = new byte[16];
      byte[] power = new byte[16];
      byte[] band = new byte[16];
      byte[] maxFre = new byte[16];
      byte[] minFre = new byte[16];
      byte[] beep = new byte[16];
      byte[] ant = new byte[16];
      int rc = intRet(invokeAny(reader, "GetUHFInformation", version, power, band, maxFre, minFre, beep, ant));
      Map<String, Object> resp = new HashMap<String, Object>();
      resp.put("rc", Integer.valueOf(rc));
      resp.put("version", bytesToHex(version));
      resp.put("power", bytesToHex(power));
      resp.put("band", bytesToHex(band));
      resp.put("maxFre", bytesToHex(maxFre));
      resp.put("minFre", bytesToHex(minFre));
      resp.put("beep", bytesToHex(beep));
      resp.put("ant", bytesToHex(ant));
      return resp;
    }

    throw new Exception("Unknown cmd: " + cmd);
  }

  private void requireConnected() throws Exception {
    if (reader == null) throw new Exception("Not connected");
  }

  private void disconnectInternal() {
    if (reader == null) return;
    try {
      safeInvoke(reader, "StopRead");
    } catch (Exception ignored) {
    }
    try {
      safeInvoke(reader, "DisConnect");
      safeInvoke(reader, "Disconnect");
    } catch (Exception ignored) {
    }
    reader = null;
    tagCallbackProxy = null;
    inventoryStarted = false;
  }

  private Object newCReader(String ip, int port, int readerType, int logSwitch) throws Exception {
    Class<?> cls = Class.forName("com.rfid.CReader");
    return cls.getConstructor(new Class<?>[] { String.class, int.class, int.class, int.class })
        .newInstance(new Object[] { ip, Integer.valueOf(port), Integer.valueOf(readerType), Integer.valueOf(logSwitch) });
  }

  private Object newReaderParameter() throws Exception {
    Class<?> cls = Class.forName("com.rfid.ReaderParameter");
    return cls.getConstructor(new Class<?>[] {}).newInstance(new Object[] {});
  }

  private void ensureCallback() throws Exception {
    if (tagCallbackProxy != null) return;
    final Class<?> cbClass = Class.forName("com.rfid.TagCallback");
    InvocationHandler h = (proxy, method, args) -> {
      if ("tagCallback".equals(method.getName()) && args != null && args.length == 1) {
        handleTag(args[0]);
      }
      return null;
    };
    Object proxy = Proxy.newProxyInstance(cbClass.getClassLoader(), new Class<?>[] { cbClass }, h);
    tagCallbackProxy = proxy;
    try {
      invokeAny(reader, "SetCallBack", proxy);
    } catch (NoSuchMethodException e) {
      invokeAny(reader, "SetCallback", proxy);
    }
  }

  private void handleTag(Object tag) {
    try {
      String epcId = stringFieldOrGetter(tag, "epcId");
      int rssi = intFieldOrGetter(tag, "rssi");
      int antId = intFieldOrGetter(tag, "antId");
      sendEvent("TAG", jsonObj("epcId", epcId, "rssi", Integer.valueOf(rssi), "antId", Integer.valueOf(antId)));
    } catch (Exception e) {
      sendEvent("LOG", jsonObj("level", "warn", "message", "Tag parse error: " + e));
    }
  }

  private static String stringFieldOrGetter(Object obj, String name) throws Exception {
    try {
      Field f = obj.getClass().getField(name);
      Object v = f.get(obj);
      return v == null ? "" : String.valueOf(v);
    } catch (NoSuchFieldException ignored) {
    }
    String getter = "get" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
    try {
      Method m = obj.getClass().getMethod(getter, new Class<?>[] {});
      Object v = m.invoke(obj, new Object[] {});
      return v == null ? "" : String.valueOf(v);
    } catch (NoSuchMethodException ignored) {
    }
    return "";
  }

  private static int intFieldOrGetter(Object obj, String name) throws Exception {
    try {
      Field f = obj.getClass().getField(name);
      Object v = f.get(obj);
      return v instanceof Number ? ((Number) v).intValue() : safeParseInt(String.valueOf(v), 0);
    } catch (NoSuchFieldException ignored) {
    }
    String getter = "get" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
    try {
      Method m = obj.getClass().getMethod(getter, new Class<?>[] {});
      Object v = m.invoke(obj, new Object[] {});
      return v instanceof Number ? ((Number) v).intValue() : safeParseInt(String.valueOf(v), 0);
    } catch (NoSuchMethodException ignored) {
    }
    return 0;
  }

  private static Object invokeAny(Object target, String name, Object... args) throws Exception {
    Method[] methods = target.getClass().getMethods();
    for (Method m : methods) {
      if (!m.getName().equals(name)) continue;
      if (m.getParameterTypes().length != args.length) continue;
      Object[] converted = tryConvert(m.getParameterTypes(), args);
      if (converted == null) continue;
      return m.invoke(target, converted);
    }
    throw new NoSuchMethodException(target.getClass().getName() + "." + name);
  }

  private static void safeInvoke(Object target, String name, Object... args) {
    try {
      invokeAny(target, name, args);
    } catch (Exception ignored) {
    }
  }

  private static Object[] tryConvert(Class<?>[] paramTypes, Object[] args) {
    Object[] out = new Object[args.length];
    for (int i = 0; i < args.length; i++) {
      Object v = args[i];
      Class<?> p = paramTypes[i];
      Object cv = convertOne(p, v);
      if (cv == CONVERT_FAIL) return null;
      out[i] = cv;
    }
    return out;
  }

  private static final Object CONVERT_FAIL = new Object();

  private static Object convertOne(Class<?> p, Object v) {
    if (v == null) {
      if (!p.isPrimitive()) return null;
      if (p == boolean.class) return Boolean.FALSE;
      if (p == byte.class) return Byte.valueOf((byte) 0);
      if (p == short.class) return Short.valueOf((short) 0);
      if (p == int.class) return Integer.valueOf(0);
      if (p == long.class) return Long.valueOf(0L);
      if (p == float.class) return Float.valueOf(0f);
      if (p == double.class) return Double.valueOf(0d);
      return CONVERT_FAIL;
    }

    if (p.isInstance(v)) return v;

    if (p == String.class) return String.valueOf(v);

    if (p == int.class || p == Integer.class) {
      if (v instanceof Number) return Integer.valueOf(((Number) v).intValue());
      return Integer.valueOf(safeParseInt(String.valueOf(v), 0));
    }
    if (p == byte.class || p == Byte.class) {
      if (v instanceof Number) return Byte.valueOf(((Number) v).byteValue());
      return Byte.valueOf((byte) safeParseInt(String.valueOf(v), 0));
    }
    if (p == boolean.class || p == Boolean.class) {
      if (v instanceof Boolean) return v;
      String s = String.valueOf(v).trim().toLowerCase();
      return Boolean.valueOf("1".equals(s) || "true".equals(s) || "yes".equals(s));
    }
    if (p == byte[].class && v instanceof byte[]) return v;

    return CONVERT_FAIL;
  }

  private static int intRet(Object ret) {
    if (ret == null) return 0;
    if (ret instanceof Number) return ((Number) ret).intValue();
    return safeParseInt(String.valueOf(ret), 0);
  }

  private static int safeParseInt(String s, int def) {
    try {
      return Integer.parseInt(s.trim());
    } catch (Exception e) {
      return def;
    }
  }

  private static int intv(Object v, int def) {
    if (v == null) return def;
    if (v instanceof Number) return ((Number) v).intValue();
    return safeParseInt(String.valueOf(v), def);
  }

  private static String str(Object v, String def) {
    if (v == null) return def;
    return String.valueOf(v);
  }

  // Minimal JSON parsing for flat objects: {"k":"v","n":123}
  // This is ONLY for our local bridge protocol.
  private static Map<String, Object> parseFlatJsonObject(String json) {
    Map<String, Object> out = new HashMap<String, Object>();
    String s = json.trim();
    if (s.isEmpty() || "{}".equals(s)) return out;
    if (s.charAt(0) != '{' || s.charAt(s.length() - 1) != '}') return out;
    s = s.substring(1, s.length() - 1).trim();
    if (s.isEmpty()) return out;
    String[] pairs = s.split(",");
    for (String pair : pairs) {
      int idx = pair.indexOf(':');
      if (idx <= 0) continue;
      String k = unquote(pair.substring(0, idx).trim());
      String raw = pair.substring(idx + 1).trim();
      Object v = parseJsonValue(raw);
      out.put(k, v);
    }
    return out;
  }

  private static Object parseJsonValue(String raw) {
    if (raw.startsWith("\"") && raw.endsWith("\"")) return unquote(raw);
    if ("true".equals(raw)) return Boolean.TRUE;
    if ("false".equals(raw)) return Boolean.FALSE;
    if ("null".equals(raw)) return null;
    try {
      if (raw.contains(".")) return Double.valueOf(Double.parseDouble(raw));
      return Integer.valueOf(Integer.parseInt(raw));
    } catch (Exception ignored) {
    }
    return raw;
  }

  private static String unquote(String s) {
    if (s.startsWith("\"") && s.endsWith("\"") && s.length() >= 2) {
      s = s.substring(1, s.length() - 1);
    }
    return s.replace("\\\"", "\"").replace("\\\\", "\\");
  }

  private void sendResOk(int id, String jsonPayload) {
    sendLine("RES\t" + id + "\tOK\t" + jsonPayload);
  }

  private void sendResErr(int id, String msg) {
    sendLine("RES\t" + id + "\tERR\t" + escapeOneLine(msg));
  }

  private void sendEvent(String evt, String jsonPayload) {
    sendLine("EVT\t" + evt + "\t" + jsonPayload);
  }

  private void sendLine(String line) {
    synchronized (outLock) {
      System.out.print(line);
      System.out.print("\n");
      System.out.flush();
    }
  }

  private static String escapeOneLine(String s) {
    if (s == null) return "";
    return s.replace("\n", " ").replace("\r", " ").replace("\t", " ");
  }

  private static String bytesToHex(byte[] b) {
    StringBuilder sb = new StringBuilder(b.length * 2);
    for (int i = 0; i < b.length; i++) {
      int v = b[i] & 0xFF;
      String h = Integer.toHexString(v).toUpperCase();
      if (h.length() == 1) sb.append('0');
      sb.append(h);
    }
    return sb.toString();
  }

  private static String toJson(Object obj) {
    if (obj == null) return "null";
    if (obj instanceof String) return quoteJson((String) obj);
    if (obj instanceof Number) return String.valueOf(obj);
    if (obj instanceof Boolean) return ((Boolean) obj).booleanValue() ? "true" : "false";
    if (obj instanceof Map) {
      @SuppressWarnings("unchecked")
      Map<String, Object> m = (Map<String, Object>) obj;
      StringBuilder sb = new StringBuilder();
      sb.append('{');
      boolean first = true;
      for (Map.Entry<String, Object> e : m.entrySet()) {
        if (!first) sb.append(',');
        first = false;
        sb.append(quoteJson(e.getKey()));
        sb.append(':');
        sb.append(toJson(e.getValue()));
      }
      sb.append('}');
      return sb.toString();
    }
    return quoteJson(String.valueOf(obj));
  }

  private static String jsonObj(Object... kv) {
    Map<String, Object> m = new HashMap<String, Object>();
    for (int i = 0; i + 1 < kv.length; i += 2) {
      m.put(String.valueOf(kv[i]), kv[i + 1]);
    }
    return toJson(m);
  }

  private static String quoteJson(String s) {
    StringBuilder sb = new StringBuilder();
    sb.append('"');
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '\\' || c == '"') sb.append('\\').append(c);
      else if (c == '\n') sb.append("\\n");
      else if (c == '\r') sb.append("\\r");
      else if (c == '\t') sb.append("\\t");
      else sb.append(c);
    }
    sb.append('"');
    return sb.toString();
  }
}
