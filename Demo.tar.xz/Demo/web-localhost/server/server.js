#!/usr/bin/env node
/* eslint-disable no-console */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const net = require('net');
const { spawn } = require('child_process');
const { URL } = require('url');

function parseArgs(argv) {
  const args = { port: 8787, host: '127.0.0.1' };
  for (let i = 2; i < argv.length; i++) {
    const v = argv[i];
    if (v === '--port') args.port = Number(argv[++i]);
    else if (v === '--host') args.host = String(argv[++i]);
  }
  return args;
}

function json(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  });
  res.end(body);
}

async function readJsonBody(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const raw = Buffer.concat(chunks).toString('utf8').trim();
  if (!raw) return {};
  return JSON.parse(raw);
}

function contentTypeFor(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  switch (ext) {
    case '.html':
      return 'text/html; charset=utf-8';
    case '.js':
      return 'text/javascript; charset=utf-8';
    case '.css':
      return 'text/css; charset=utf-8';
    case '.svg':
      return 'image/svg+xml';
    case '.png':
      return 'image/png';
    case '.ico':
      return 'image/x-icon';
    default:
      return 'application/octet-stream';
  }
}

class Bridge {
  constructor({ rootDir }) {
    this.rootDir = rootDir;
    this.proc = null;
    this.nextId = 1;
    this.pending = new Map();
    this.listeners = new Set();
    this.buffer = '';
  }

  onEvent(handler) {
    this.listeners.add(handler);
    return () => this.listeners.delete(handler);
  }

  emit(evt) {
    for (const handler of this.listeners) handler(evt);
  }

  start() {
    if (this.proc) return;

    const bridgeOutDir = path.resolve(this.rootDir, 'server', 'bridge-out');
    const cReaderJar = path.resolve(this.rootDir, '..', '..', 'SDK', 'Java-linux', 'CReader.jar');
    const mainClass = 'com.st8504.bridge.BridgeMain';

    const classPath = [bridgeOutDir, cReaderJar].join(path.delimiter);
    const javaArgs = ['-cp', classPath, mainClass];

    if (!fs.existsSync(cReaderJar)) {
      throw new Error(`Missing CReader.jar at: ${cReaderJar}`);
    }
    if (!fs.existsSync(path.join(bridgeOutDir, 'com', 'st8504', 'bridge', 'BridgeMain.class'))) {
      throw new Error(`Java bridge is not built. Run: ${path.resolve(this.rootDir, 'build-bridge.sh')}`);
    }

    this.proc = spawn('java', javaArgs, {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env },
    });

    this.proc.stdout.setEncoding('utf8');
    this.proc.stdout.on('data', (chunk) => this.#handleStdout(chunk));

    this.proc.stderr.setEncoding('utf8');
    this.proc.stderr.on('data', (chunk) => {
      this.emit({ type: 'bridge-stderr', message: String(chunk) });
    });

    this.proc.on('exit', (code, signal) => {
      const msg = `Java bridge exited (code=${code}, signal=${signal})`;
      for (const [, p] of this.pending) p.reject(new Error(msg));
      this.pending.clear();
      this.proc = null;
      this.emit({ type: 'bridge-exit', message: msg });
    });
  }

  stop() {
    if (!this.proc) return;
    this.proc.kill();
    this.proc = null;
  }

  #handleStdout(chunk) {
    this.buffer += chunk;
    while (true) {
      const idx = this.buffer.indexOf('\n');
      if (idx === -1) return;
      const line = this.buffer.slice(0, idx).trimEnd();
      this.buffer = this.buffer.slice(idx + 1);
      if (!line) continue;
      this.#handleLine(line);
    }
  }

  #handleLine(line) {
    const parts = line.split('\t');
    const kind = parts[0];

    if (kind === 'RES') {
      const id = Number(parts[1]);
      const okOrErr = parts[2];
      const payload = parts.slice(3).join('\t');
      const pending = this.pending.get(id);
      if (!pending) return;
      this.pending.delete(id);
      if (okOrErr === 'OK') pending.resolve(payload ? JSON.parse(payload) : {});
      else pending.reject(new Error(payload || 'Unknown error'));
      return;
    }

    if (kind === 'EVT') {
      const evtType = parts[1];
      const payload = parts.slice(2).join('\t');
      let data = payload;
      try {
        data = payload ? JSON.parse(payload) : {};
      } catch {
        // Keep raw
      }
      this.emit({ type: 'bridge-event', event: evtType, data });
      return;
    }

    this.emit({ type: 'bridge-unknown', line });
  }

  request(cmd, args = {}) {
    this.start();
    const id = this.nextId++;
    const line = `REQ\t${id}\t${cmd}\t${JSON.stringify(args)}\n`;

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timeout waiting for ${cmd}`));
      }, 10_000);

      this.pending.set(id, {
        resolve: (v) => {
          clearTimeout(timeout);
          resolve(v);
        },
        reject: (e) => {
          clearTimeout(timeout);
          reject(e);
        },
      });

      this.proc.stdin.write(line);
    });
  }
}

function serveStatic({ webDir }, req, res) {
  const urlObj = new URL(req.url, 'http://127.0.0.1');
  let pathname = urlObj.pathname;
  if (pathname === '/') pathname = '/index.html';
  pathname = pathname.replaceAll('..', '');
  const filePath = path.join(webDir, pathname);
  if (!filePath.startsWith(webDir)) return false;
  if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) return false;
  const data = fs.readFileSync(filePath);
  res.writeHead(200, {
    'content-type': contentTypeFor(filePath),
    'content-length': data.length,
    'cache-control': 'no-store',
  });
  res.end(data);
  return true;
}

function findDefaultSubnet() {
  const ifaces = os.networkInterfaces();
  for (const [, addrs] of Object.entries(ifaces)) {
    for (const addr of addrs || []) {
      if (addr.family !== 'IPv4') continue;
      if (addr.internal) continue;
      // Heuristic: use /24 of the first non-internal IPv4
      const parts = addr.address.split('.');
      if (parts.length !== 4) continue;
      return `${parts[0]}.${parts[1]}.${parts[2]}.0/24`;
    }
  }
  return null;
}

async function scanTcpPort({ port, timeoutMs = 120, concurrency = 64 }) {
  const subnet = findDefaultSubnet();
  if (!subnet) return { subnet: null, devices: [] };

  const base = subnet.split('/')[0].split('.');
  const prefix = `${base[0]}.${base[1]}.${base[2]}.`;

  const ips = [];
  for (let i = 1; i <= 254; i++) ips.push(`${prefix}${i}`);

  const devices = [];
  let idx = 0;

  async function worker() {
    while (true) {
      const ip = ips[idx++];
      if (!ip) return;
      const ok = await new Promise((resolve) => {
        const socket = new net.Socket();
        let done = false;

        function finish(result) {
          if (done) return;
          done = true;
          try {
            socket.destroy();
          } catch {}
          resolve(result);
        }

        socket.setTimeout(timeoutMs);
        socket.once('connect', () => finish(true));
        socket.once('timeout', () => finish(false));
        socket.once('error', () => finish(false));
        socket.connect(port, ip);
      });
      if (ok) devices.push({ ip, port });
    }
  }

  const workers = [];
  for (let i = 0; i < concurrency; i++) workers.push(worker());
  await Promise.all(workers);

  return { subnet, devices };
}

function main() {
  const args = parseArgs(process.argv);
  const rootDir = path.resolve(__dirname, '..');
  const webDir = path.resolve(rootDir, 'web');

  const bridge = new Bridge({ rootDir });

  const sseClients = new Set();
  function sseBroadcast(event, data) {
    const payload = JSON.stringify(data);
    const msg = `event: ${event}\ndata: ${payload}\n\n`;
    for (const res of sseClients) {
      try {
        res.write(msg);
      } catch {
        sseClients.delete(res);
      }
    }
  }

  bridge.onEvent((evt) => {
    if (evt.type === 'bridge-event') sseBroadcast(evt.event, evt.data);
    else if (evt.type === 'bridge-stderr') sseBroadcast('log', { level: 'stderr', message: evt.message });
    else if (evt.type === 'bridge-exit') sseBroadcast('log', { level: 'error', message: evt.message });
  });

  const server = http.createServer(async (req, res) => {
    try {
      const urlObj = new URL(req.url, `http://${args.host}`);

      if (req.method === 'GET' && urlObj.pathname === '/api/events') {
        res.writeHead(200, {
          'content-type': 'text/event-stream; charset=utf-8',
          'cache-control': 'no-store',
          connection: 'keep-alive',
        });
        res.write(`event: hello\ndata: ${JSON.stringify({ ok: true, host: os.hostname() })}\n\n`);
        sseClients.add(res);
        req.on('close', () => sseClients.delete(res));
        return;
      }

      if (req.method === 'GET' && urlObj.pathname === '/api/status') {
        const status = await bridge.request('STATUS', {});
        return json(res, 200, { ok: true, status });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/scan') {
        const body = await readJsonBody(req);
        const port = Number(body.port || 27011);
        const result = await scanTcpPort({ port, timeoutMs: 120, concurrency: 64 });
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/connect') {
        const body = await readJsonBody(req);
        const result = await bridge.request('CONNECT', body);
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/disconnect') {
        const result = await bridge.request('DISCONNECT', {});
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/inventory/params') {
        const body = await readJsonBody(req);
        const result = await bridge.request('SET_INV_PARAM', body);
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/inventory/start') {
        const body = await readJsonBody(req);
        const result = await bridge.request('START_READ', body);
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/inventory/stop') {
        const result = await bridge.request('STOP_READ', {});
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/read') {
        const body = await readJsonBody(req);
        const result = await bridge.request('READ', body);
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/write') {
        const body = await readJsonBody(req);
        const result = await bridge.request('WRITE', body);
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/settings/power') {
        const body = await readJsonBody(req);
        const result = await bridge.request('SET_POWER', body);
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/settings/region') {
        const body = await readJsonBody(req);
        const result = await bridge.request('SET_REGION', body);
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'POST' && urlObj.pathname === '/api/settings/gpio') {
        const body = await readJsonBody(req);
        const result = await bridge.request('GPIO', body);
        return json(res, 200, { ok: true, result });
      }

      if (req.method === 'GET' && urlObj.pathname === '/api/info') {
        const result = await bridge.request('GET_INFO', {});
        return json(res, 200, { ok: true, result });
      }

      if (serveStatic({ webDir }, req, res)) return;

      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end('Not found');
    } catch (err) {
      json(res, 500, { ok: false, error: String(err && err.message ? err.message : err) });
    }
  });

  server.listen(args.port, args.host, () => {
    console.log(`UHF localhost web UI: http://${args.host}:${args.port}`);
  });
}

main();
