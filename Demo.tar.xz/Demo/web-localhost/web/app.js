const $ = (id) => document.getElementById(id);

const LS_KEY = 'st8504.uhf.localhost.v1';

function logLine(msg) {
  const el = $('logs');
  const t = new Date().toISOString().replace('T', ' ').replace('Z', '');
  el.textContent = `[${t}] ${msg}\n` + el.textContent;
}

async function api(path, body) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || 'Request failed');
  return data.result ?? data;
}

function setStatus(text, kind) {
  const pill = $('statusPill');
  pill.textContent = text;
  if (kind === 'ok') pill.style.borderColor = 'rgba(47,224,176,0.55)';
  else if (kind === 'warn') pill.style.borderColor = 'rgba(255,209,93,0.55)';
  else if (kind === 'err') pill.style.borderColor = 'rgba(255,93,122,0.55)';
  else pill.style.borderColor = 'rgba(255,255,255,0.08)';
}

function saveUiState() {
  const state = {
    conn: getConnArgs(),
    inv: getInvParams(),
    autoConnect: $('autoConnect').checked,
  };
  localStorage.setItem(LS_KEY, JSON.stringify(state));
}

function loadUiState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return;
    const state = JSON.parse(raw);
    if (state?.conn?.ip) $('ip').value = state.conn.ip;
    if (state?.conn?.port) $('port').value = String(state.conn.port);
    if (state?.conn?.readerType) $('readerType').value = String(state.conn.readerType);
    if (state?.conn?.logSwitch !== undefined) $('logSwitch').value = String(state.conn.logSwitch);
    if (state?.inv?.qValue !== undefined) $('qValue').value = String(state.inv.qValue);
    if (state?.inv?.session !== undefined) $('session').value = String(state.inv.session);
    if (state?.inv?.scanTime !== undefined) $('scanTime').value = String(state.inv.scanTime);
    if (state?.inv?.antennaMask !== undefined) $('antennaMask').value = String(state.inv.antennaMask);
    if (state?.inv?.tidPtr !== undefined) $('tidPtr').value = String(state.inv.tidPtr);
    if (state?.inv?.tidLen !== undefined) $('tidLen').value = String(state.inv.tidLen);
    $('autoConnect').checked = Boolean(state?.autoConnect);
  } catch {
    // ignore
  }
}

const tags = new Map();

function renderTags() {
  const tbody = $('tagTable');
  const rows = [...tags.values()].sort((a, b) => b.count - a.count);
  tbody.innerHTML = rows
    .map((t) => {
      return `<tr>
        <td>${t.epcId}</td>
        <td>${t.count}</td>
        <td>${t.rssi}</td>
        <td>${t.antId}</td>
        <td>${new Date(t.lastSeen).toLocaleTimeString()}</td>
      </tr>`;
    })
    .join('');

  // click-to-fill EPC for read/write
  for (const tr of tbody.querySelectorAll('tr')) {
    tr.addEventListener('click', () => {
      const epc = tr.querySelector('td')?.textContent || '';
      $('rwEpc').value = epc;
    });
  }
}

function upsertTag(tag) {
  const k = tag.epcId || '';
  if (!k) return;
  const prev = tags.get(k);
  const now = Date.now();
  if (!prev) {
    tags.set(k, { ...tag, count: 1, lastSeen: now });
  } else {
    tags.set(k, {
      ...prev,
      rssi: tag.rssi ?? prev.rssi,
      antId: tag.antId ?? prev.antId,
      count: prev.count + 1,
      lastSeen: now,
    });
  }
  renderTags();
}

function getConnArgs() {
  return {
    ip: $('ip').value.trim(),
    port: Number($('port').value),
    readerType: Number($('readerType').value),
    logSwitch: Number($('logSwitch').value),
  };
}

function getInvParams() {
  return {
    qValue: Number($('qValue').value),
    session: Number($('session').value),
    scanTime: Number($('scanTime').value),
    antennaMask: Number($('antennaMask').value),
    tidPtr: Number($('tidPtr').value),
    tidLen: Number($('tidLen').value),
  };
}

function renderAntennaChoices() {
  const count = Number($('readerType').value || 16);
  const wrap = $('antennaChoices');
  wrap.innerHTML = '';
  for (let i = 1; i <= count; i++) {
    const id = `ant_${i}`;
    const label = document.createElement('label');
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.id = id;
    input.dataset.ant = String(i);
    const text = document.createElement('span');
    text.textContent = `ANT${i}`;
    label.appendChild(input);
    label.appendChild(text);
    wrap.appendChild(label);
  }
  syncAntennaChecksFromMask();
  for (const cb of wrap.querySelectorAll('input[type="checkbox"]')) {
    cb.addEventListener('change', () => {
      syncAntennaMaskFromChecks();
      saveUiState();
    });
  }
}

function syncAntennaMaskFromChecks() {
  const wrap = $('antennaChoices');
  let mask = 0;
  for (const cb of wrap.querySelectorAll('input[type="checkbox"]')) {
    if (!cb.checked) continue;
    const ant = Number(cb.dataset.ant);
    if (ant >= 1 && ant <= 31) mask |= 1 << (ant - 1);
  }
  $('antennaMask').value = String(mask);
}

function syncAntennaChecksFromMask() {
  const mask = Number($('antennaMask').value || 0);
  const wrap = $('antennaChoices');
  for (const cb of wrap.querySelectorAll('input[type="checkbox"]')) {
    const ant = Number(cb.dataset.ant);
    cb.checked = Boolean(mask & (1 << (ant - 1)));
  }
}

async function refreshStatus() {
  const res = await fetch('/api/status');
  const data = await res.json();
  if (!data.ok) return;
  const st = data.status;
  if (st.connected) setStatus('Connected', 'ok');
  else setStatus('Disconnected', 'err');
}

function bind() {
  for (const id of ['ip', 'port', 'readerType', 'logSwitch', 'qValue', 'session', 'scanTime', 'antennaMask', 'tidPtr', 'tidLen', 'autoConnect']) {
    $(id).addEventListener('change', () => {
      if (id === 'readerType') renderAntennaChoices();
      if (id === 'antennaMask') syncAntennaChecksFromMask();
      saveUiState();
    });
  }

  $('btnConnect').onclick = async () => {
    try {
      setStatus('Connecting...', 'warn');
      await api('/api/connect', getConnArgs());
      await refreshStatus();
      logLine('Connected.');
    } catch (e) {
      setStatus('Disconnected', 'err');
      logLine(`Connect error: ${e.message}`);
    }
  };

  $('btnScan').onclick = async () => {
    try {
      const port = Number($('port').value || 27011);
      logLine(`Scanning local network for port ${port} (this can take ~10-30s)...`);
      const result = await api('/api/scan', { port });
      if (!result?.devices?.length) {
        logLine(`Scan done. No devices found on ${result?.subnet || 'local subnet'}.`);
        return;
      }
      logLine(`Scan done. Found ${result.devices.length} device(s): ${result.devices.map((d) => d.ip).join(', ')}`);
      $('ip').value = result.devices[0].ip;
      saveUiState();
    } catch (e) {
      logLine(`Scan error: ${e.message}`);
    }
  };

  $('btnDisconnect').onclick = async () => {
    try {
      await api('/api/disconnect', {});
      await refreshStatus();
      logLine('Disconnected.');
    } catch (e) {
      logLine(`Disconnect error: ${e.message}`);
    }
  };

  $('btnInfo').onclick = async () => {
    try {
      const res = await fetch('/api/info');
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'info failed');
      $('settingsOut').textContent = JSON.stringify(data.result, null, 2);
      logLine('Got reader info.');
    } catch (e) {
      logLine(`Info error: ${e.message}`);
    }
  };

  $('btnInvStart').onclick = async () => {
    try {
      await api('/api/inventory/params', getInvParams());
      await api('/api/inventory/start', {});
      logLine('Inventory started.');
    } catch (e) {
      logLine(`Inventory start error: ${e.message}`);
    }
  };

  $('btnInvStop').onclick = async () => {
    try {
      await api('/api/inventory/stop', {});
      logLine('Inventory stopped.');
    } catch (e) {
      logLine(`Inventory stop error: ${e.message}`);
    }
  };

  $('btnInvClear').onclick = () => {
    tags.clear();
    renderTags();
    logLine('Cleared tag list.');
  };

  $('btnRead').onclick = async () => {
    try {
      const body = {
        epc: $('rwEpc').value.trim(),
        mem: Number($('rwMem').value),
        wordPtr: Number($('rwWordPtr').value),
        num: Number($('rwNum').value),
        password: $('rwPwd').value.trim(),
      };
      const result = await api('/api/read', body);
      $('rwOut').textContent = JSON.stringify(result, null, 2);
      logLine('Read completed.');
    } catch (e) {
      $('rwOut').textContent = e.message;
      logLine(`Read error: ${e.message}`);
    }
  };

  $('btnWrite').onclick = async () => {
    try {
      const body = {
        epc: $('rwEpc').value.trim(),
        mem: Number($('rwMem').value),
        wordPtr: Number($('rwWordPtr').value),
        password: $('rwPwd').value.trim(),
        data: $('rwData').value.trim().replaceAll(' ', ''),
      };
      const result = await api('/api/write', body);
      $('rwOut').textContent = JSON.stringify(result, null, 2);
      logLine('Write completed.');
    } catch (e) {
      $('rwOut').textContent = e.message;
      logLine(`Write error: ${e.message}`);
    }
  };

  $('btnSetPower').onclick = async () => {
    try {
      const result = await api('/api/settings/power', { power: Number($('power').value) });
      $('settingsOut').textContent = JSON.stringify(result, null, 2);
      logLine('Set power done.');
    } catch (e) {
      logLine(`Set power error: ${e.message}`);
    }
  };

  $('btnSetRegion').onclick = async () => {
    try {
      const result = await api('/api/settings/region', {
        band: Number($('band').value),
        maxfre: Number($('maxfre').value),
        minfre: Number($('minfre').value),
      });
      $('settingsOut').textContent = JSON.stringify(result, null, 2);
      logLine('Set region done.');
    } catch (e) {
      logLine(`Set region error: ${e.message}`);
    }
  };

  $('btnGpioGet').onclick = async () => {
    try {
      const result = await api('/api/settings/gpio', { op: 'get' });
      $('settingsOut').textContent = JSON.stringify(result, null, 2);
      logLine('GPIO status read.');
    } catch (e) {
      logLine(`GPIO get error: ${e.message}`);
    }
  };

  $('btnGpioSet').onclick = async () => {
    try {
      const result = await api('/api/settings/gpio', { op: 'set', value: Number($('gpioValue').value) });
      $('settingsOut').textContent = JSON.stringify(result, null, 2);
      logLine('GPIO set done.');
    } catch (e) {
      logLine(`GPIO set error: ${e.message}`);
    }
  };
}

function startEvents() {
  const ev = new EventSource('/api/events');
  ev.addEventListener('hello', (e) => {
    logLine(`Event stream connected: ${e.data}`);
  });
  ev.addEventListener('TAG', (e) => {
    try {
      const tag = JSON.parse(e.data);
      upsertTag(tag);
    } catch {
      // ignore
    }
  });
  ev.addEventListener('STATUS', (e) => {
    logLine(`STATUS: ${e.data}`);
    refreshStatus();
  });
  ev.addEventListener('log', (e) => {
    try {
      const m = JSON.parse(e.data);
      logLine(`${m.level}: ${String(m.message).trim()}`);
    } catch {
      logLine(e.data);
    }
  });
  ev.onerror = () => {
    logLine('Event stream error (will auto-retry).');
  };
}

loadUiState();
renderAntennaChoices();
bind();
startEvents();
refreshStatus();

if ($('autoConnect').checked) {
  $('btnConnect').click();
}
