param(
  [int]$Port = 8787
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ServerJs = Join-Path $ScriptDir "web-localhost/server/server.js"

node $ServerJs --port $Port
