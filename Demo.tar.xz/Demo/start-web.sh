#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WEB_DIR="$(cd -- "$SCRIPT_DIR/web-localhost" && pwd)"

PORT="${PORT:-8787}"
if [[ $# -ge 1 ]]; then
  PORT="$1"
fi

export PORT
exec "$WEB_DIR/run.sh"
