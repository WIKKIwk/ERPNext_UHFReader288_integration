@echo off
setlocal

if not defined PORT set "PORT=8787"
if not "%1"=="" set "PORT=%1"

set "SCRIPT_DIR=%~dp0"

node "%SCRIPT_DIR%web-localhost\\server\\server.js" --port %PORT%

endlocal
